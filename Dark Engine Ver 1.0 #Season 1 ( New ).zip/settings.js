const fs = require('fs')

global.botname = "Drak Engine"
global.version = "1.0.0"
global.owner = "6285704308592"
global.footer = "SanzzCytReal"
global.idch = "120363420431815798@newsletter"
global.packname = "SanzzCyt"
// atur delay global (dalam milidetik)
global.delaypushkontak = 1000; 
global.savenomor = 'settig nama sv di sinj'
//Global Thumb
global.dana = '';
global.ovo = '';
global.gopay = '';
global.qris = 'https://linkqris.com/xxxx';
//Global Mess
global.mess = {
	owner: "*[ Akses Ditolak ]*\nFitur ini hanya untuk owner bot!",
    admins: "*[ Akses Ditolak ]*\nFitur ini hanya untuk admin grup!",
	botadmins: "*[ Akses Ditolak ]*\nFitur ini hanya untuk ketika bot Menjadi Admin!",
	group: "*[ Akses Ditolak ]*\nFitur ini hanya untuk dalam grup!",
	premium: "*[ Akses Ditolak ]*\nFitur ini hanya untuk user premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done',
	qris: 'https://files.catbox.moe/jhdtkk.jpg',
	nama: "SanzzCyt Official",
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
