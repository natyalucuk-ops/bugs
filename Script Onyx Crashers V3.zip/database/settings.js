// Module
const fs = require('fs')

//Bot Settings
global.connect = true // True For Pairing // False For Qr
global.publicX = true // True For Public // False For Self
global.owner = ['083191414167'] //Own Number
global.developer = "L K B" //Dev Name
global.botname = "Onyx Crasher's" //Bot Name
global.version = "3.0.0" //Version Bot

//Sticker Setiings
global.packname = "Sticker By" //Pack Name 
global.author = "LKBTzyy" // Author

//Social Media Settings
global.ytube = "https://youtube.com/@lkb-999"
global.ttok = "tiktok.com/@lkbarifreall"
global.igram = "https://instagram.com/@lkbhytam"
global.tgram = "https://t.me/LKBbae"
global.limitCount = 1,

//Bug Name Settings
global.bak = {
Ios: " 𝐑̸̲͟𝐚𝐩̅𝐢̶̶̅͟𝐩̶̋𝐩̶𝐩̶̋𝐌𝐨̤͋𝐝̈́𝐬̽͢𝐬�? ",
Andro: "𝐑̸̲͟𝐚𝐩̅𝐢̶̶̅͟𝐩̶̋𝐩̶𝐩̶̋𝐌𝐨̤͋𝐝̈́𝐬̽͢𝐬�?", 
Crash: " ̶𝐑̸̲͟𝐚𝐩̅𝐢̶̶̅͟𝐩̶̋𝐩̶𝐩̶̋𝐌𝐨̤͋𝐝̈́𝐬̽͢𝐬�? ̶",
Freeze: "𝐑̸̲͟𝐚𝐩̅𝐢̶̶̅͟𝐩̶̋𝐩̶𝐩̶̋𝐌𝐨̤͋𝐝̈́𝐬̽͢𝐬�?",
Ui: "𝐑̸̲͟𝐚𝐩̅𝐢̶̶̅͟𝐩̶̋𝐩̶𝐩̶̋𝐌𝐨̤͋𝐝̈́𝐬̽͢𝐬�?"
}

//System Bot Settings
global.prefa = ['','!','.',',','🐤','🗿'] // Prefix // Not Change

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})