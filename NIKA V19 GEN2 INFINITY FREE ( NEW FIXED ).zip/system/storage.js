const {
  proto,
  jidDecode,
  getContentType,
  areJidsSameUser
} = require("@whiskeysockets/baileys")

const axios = require("axios")
const fs = require("fs")
const util = require("util")
const Jimp = require("jimp")
const moment = require("moment-timezone")
const { sizeFormatter } = require("human-readable")

const decodeJid = (jid) => {
  if (!jid) return jid
  if (/:\d+@/gi.test(jid)) {
    const decoded = jidDecode(jid)
    return decoded?.user && decoded?.server
      ? `${decoded.user}@${decoded.server}`
      : jid
  }
  return jid
}

exports.format = (...args) => util.format(...args)

exports.jsonformat = (data) =>
  JSON.stringify(data, null, 2)

exports.getRandom = (ext = "") =>
  `${Math.floor(Math.random() * 10000)}${ext}`

exports.sleep = async (ms) =>
  new Promise(resolve => setTimeout(resolve, ms))

exports.isUrl = (url) =>
  /https?:\/\/[^\s]+/gi.test(url)

exports.runtime = (seconds) => {
  seconds = Number(seconds)
  const d = Math.floor(seconds / (3600 * 24))
  const h = Math.floor(seconds % (3600 * 24) / 3600)
  const m = Math.floor(seconds % 3600 / 60)
  const s = Math.floor(seconds % 60)
  return [d && `${d} hari`, h && `${h} jam`, m && `${m} menit`, s && `${s} detik`]
    .filter(Boolean)
    .join(", ")
}

exports.clockString = (ms) => {
  let h = isNaN(ms) ? "--" : Math.floor(ms / 3600000)
  let m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, "0")).join(":")
}

exports.tanggal = (numer) => {
  const myMonths = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"]
  const myDays = ["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"]
  const tgl = new Date(numer)
  return `${myDays[tgl.getDay()]}, ${tgl.getDate()} ${myMonths[tgl.getMonth()]} ${tgl.getFullYear()}`
}

exports.getTime = (format, date) =>
  moment(date).tz("Asia/Jakarta").format(format)

exports.fetchJson = async (url, options = {}) => {
  const res = await axios({
    method: "GET",
    url,
    headers: { "User-Agent": "Mozilla/5.0" },
    ...options
  })
  return res.data
}

exports.getBuffer = async (url, options = {}) => {
  const res = await axios({
    method: "GET",
    url,
    responseType: "arraybuffer",
    headers: { "User-Agent": "Mozilla/5.0" },
    ...options
  })
  return res.data
}

exports.parseMention = (text = "") =>
  [...text.matchAll(/@(\d{5,16})/g)].map(v => v[1] + "@s.whatsapp.net")

exports.getGroupAdmins = (participants = []) =>
  participants
    .filter(p => p.admin)
    .map(p => p.id)

exports.formatp = sizeFormatter({
  std: "JEDEC",
  decimalPlaces: 2
})

exports.generateProfilePicture = async (buffer) => {
  const jimp = await Jimp.read(buffer)
  const min = jimp.getWidth()
  const max = jimp.getHeight()
  const cropped = jimp.crop(0, 0, min, max)
  return {
    img: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG),
    preview: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG)
  }
}

exports.smsg = (sock, m, store) => {
  if (!m) return m
  const M = proto.WebMessageInfo

  if (m.key) {
    m.id = m.key.id
    m.chat = m.key.remoteJid
    m.fromMe = m.key.fromMe
    m.isGroup = m.chat.endsWith("@g.us")
    m.sender = decodeJid(
      m.fromMe
        ? sock.user.id
        : m.participant || m.key.participant || m.chat
    )
    if (m.isGroup) m.participant = decodeJid(m.key.participant)
  }

  if (m.message) {
    m.mtype = getContentType(m.message)
    m.msg =
      m.mtype === "viewOnceMessage"
        ? m.message[m.mtype].message[getContentType(m.message[m.mtype].message)]
        : m.message[m.mtype]

    m.text =
      m.msg?.text ||
      m.msg?.caption ||
      m.message.conversation ||
      ""

    m.mentionedJid = m.msg?.contextInfo?.mentionedJid || []

    const quoted = m.msg?.contextInfo?.quotedMessage
    if (quoted) {
      const type = Object.keys(quoted)[0]
      const q = quoted[type]

      m.quoted = {
        type,
        text: q?.text || q?.caption || "",
        id: m.msg.contextInfo.stanzaId,
        chat: m.chat,
        sender: decodeJid(m.msg.contextInfo.participant),
        fromMe: areJidsSameUser(
          decodeJid(m.msg.contextInfo.participant),
          decodeJid(sock.user.id)
        )
      }

      m.getQuotedObj = async () => {
        if (!m.quoted.id) return null
        const qMsg = await store.loadMessage(m.chat, m.quoted.id, sock)
        return exports.smsg(sock, qMsg, store)
      }
    }
  }

  m.reply = (text, jid = m.chat, options = {}) =>
    sock.sendMessage(jid, { text, ...options }, { quoted: m })

  return m
}