const fs = require('fs')

global.botname = "Nika Crashh"
global.version = "18.0.0"
global.owner = "6285704308592"
global.footer = "Depayy Official"
global.idch = "120363420431815798@newsletter"
global.packname = "Depayy"

//Global Thumb
global.thumb = "https://files.catbox.moe/"

//Global Mess
global.mess = {
owner: "-[ *AKSES DITOLAK* ]-\n> *_Anda Tidak Dapat Menggunakan Fitur Ini Karena Anda Bukanlah Owner!_*", 
ownerprem: "-[ *AKSES DITOLAK* ]-\n> *_Anda Tidak Dapat Menggunakan Fitur Ini Karena Anda Bukanlah Owner & User Premium!_*"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
