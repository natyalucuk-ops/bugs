const fs = require('fs')

global.botname = "GlitchFlow Infinity"
global.version = "2.0.0"
global.owner = "62895324142219"
global.footer = "SanzzCyt Official"
global.idch = "120363415977687631@newsletter"
global.packname = "SanzzCyt Official"
global.autoAI = false
//Global Thumb
global.thumb = "https://files.catbox.moe/"

// >~~~~~ Setting Api Panel ~~~~~< //
global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "domain"
global.apikey = "ptla" // Isi api ptla
global.capikey = "ptlc" // Isi api ptlc
// >~~~~ Setting Message~~~~< //
global.mess = {
	owner: "*[ Akses Ditolak ]*\nFitur ini hanya untuk owner bot!",
    admins: "*[ Akses Ditolak ]*\nFitur ini hanya untuk admin grup!",
	botadmins: "*[ Akses Ditolak ]*\nFitur ini hanya untuk ketika bot Menjadi Admin!",
	group: "*[ Akses Ditolak ]*\nFitur ini hanya untuk dalam grup!",
	premium: "*[ Akses Ditolak ]*\nFitur ini hanya untuk user premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done',
	qris: 'https://files.catbox.moe/jhdtkk.jpg',
	nama: "SanzzCyt Official",
}


let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
